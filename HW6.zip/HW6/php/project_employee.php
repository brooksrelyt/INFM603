<!-- Sample script to show data from a database after drop-down selection - you can run at testuser2.psjconsulting.com/getclerknames-posttodisplay.php -->
Enter the name of a clerk to display orders from that clerk:
<!-- This part is just HTML - tell the file to post to displayclerkorders.php on submit - must be on same server -->
<form action="projaddtask.php" method="post"> 
<select name="clerkname">
<?php
/* This script illustrates how to pre-populate a drop-down menu from a database.   It then allows the user to select
from the drop-down list and posts the value (with variable 'clerkname') to another script to display the data*/
		// Create connection - the first argument is "localhost" because this script has to run on the same server
		// as the database - the second argument "testuser" has to be replaced by the login id for the database
		// the third argument must contain the actual password (not ********) for that id
		// the fourth argument "inclassdemo" is the name of the database
		// the resulting PHP variable $database is an object that can then be queried through the mysqli interface
		$database = new mysqli("localhost", "tdbrooks", "tdbrooks38", "tdbrooks");
	    // Check connection - return an error if something went wrong (usually because the credentials are messed up)
       if ($database->connect_error) {
        die("Connection failed: " . $database->connect_error);
      }
	  	if ( !( $result = $database->query ( "SELECT ClerkName FROM Clerks WHERE 1") ) )
			print ("Warning!   could not execute query <br />" );
	    while($row = $result->fetch_assoc()) {
			foreach ($row as $value) {
				print ("<option>$value</option>");		
			}
		}
?>
</select>
<input type = "submit" value = "Get Sales Orders" />
</form>	  
